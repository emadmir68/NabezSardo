# راهنمای اعمال تغییرات روی سایت اصلی (`nabzesardo.ir`) از طریق GitHub و Cloudflare Pages

تمامی فایل‌های نسخه جدید «نبض ساردو» — از جمله بیلد استاتیک Vite، تصاویر اختصاصی، ریدایرکت‌های SPA و هدرهای استاندارد `UTF-8` — آماده انتشار هستند.

## گام ۱: دریافت خروجی پروژه و Push به مخزن `emadmir68/NabezSardo`
از منوی بالای محیط ساخت (Export / Download ZIP یا Save to GitHub) پروژه را دانلود یا مستقیم به گیت‌هاب متصل کنید. اگر فایل ZIP را دانلود کردید، در پوشه پروژه دستورات زیر را اجرا کنید:

```bash
git init
git remote add origin https://github.com/emadmir68/NabezSardo.git
git checkout -b main
git add .
git commit -m "Deploy redesigned luxury Nabz Sardo"
git push -u origin main --force-with-lease
```

> **نکته**: اگر می‌خواهید نسخه قبلی مخزن حفظ شود، قبل از push یک شاخه پشتیبان (`git branch legacy-backup`) ایجاد کنید.

## گام ۲: تنظیم Cloudflare Pages برای `nabzesardo.ir`
1. وارد داشبورد **Cloudflare** شوید و به بخش **Workers & Pages → Create → Pages → Connect to Git** بروید (یا پروژه فعلی `nabezsardo` را باز کنید).
2. مخزن `emadmir68/NabezSardo` و شاخه تولیدی `main` را انتخاب کنید.
3. تنظیمات بیلد را روی موارد زیر قرار دهید:
   - **Framework preset**: `Vite`
   - **Build command**: `npm run build`
   - **Build output directory**: `dist`
4. در بخش **Custom domains** دامنه `nabzesardo.ir` و `www.nabzesardo.ir` را متصل نگه دارید.

## گام ۳: انتشار خودکار در آپدیت‌های بعدی (GitHub Actions)
اگر می‌خواهید دیپلوی از طریق ورک‌فلو `.github/workflows/deploy-cloudflare-pages.yml` انجام شود، در مخزن گیت‌هاب به مسیر:
`Settings → Secrets and variables → Actions → New repository secret`
بروید و این دو کلید را ثبت کنید:
- `CLOUDFLARE_API_TOKEN`
- `CLOUDFLARE_ACCOUNT_ID`

پس از اتمام این مراحل، سایت اصلی `https://nabzesardo.ir` با طراحی لوکس مجله‌ای و هیرو زنده روی CDN کلودفلر بالا می‌آید.
